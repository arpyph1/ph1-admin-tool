import { NextRequest, NextResponse } from 'next/server';
import { componentAnalyzer, ComponentInfo, ModificationPlan } from '../../../lib/componentAnalyzer';
import OpenAI from 'openai';

interface RealPageModificationRequest {
  prompt: string;
  operation: 'revise' | 'global';
  targetPage?: string;
  previewOnly?: boolean;
}

interface ModificationResult {
  originalComponent: ComponentInfo;
  modifications: ModificationPlan[];
  modifiedContent: string;
  previewUrl: string;
  backupId: string;
  canUndo: boolean;
}

export async function POST(request: NextRequest) {
  try {
    const { prompt, operation, targetPage, previewOnly }: RealPageModificationRequest = await request.json();

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    console.log('🔍 Analyzing current components...');
    
    // Step 1: Analyze current components
    let targetComponents: ComponentInfo[] = [];
    
    if (operation === 'revise' && targetPage) {
      const componentPath = getComponentPath(targetPage);
      const component = await componentAnalyzer.analyzeComponent(componentPath);
      targetComponents = [component];
    } else {
      // Global changes - analyze all components
      targetComponents = await componentAnalyzer.analyzeAllPages();
    }

    console.log(`📊 Found ${targetComponents.length} components to modify`);

    // Step 2: Generate AI-powered modification plan
    const allModifications: ModificationResult[] = [];
    
    for (const component of targetComponents) {
      console.log(`🤖 Generating modifications for ${component.componentName}...`);
      
      const modifications = await generateIntelligentModifications(component, prompt, operation);
      const modifiedContent = await componentAnalyzer.applyModifications(component, modifications);
      
      // Generate preview
      const previewUrl = await generatePreviewUrl(component.filePath, modifiedContent);
      
      const result: ModificationResult = {
        originalComponent: component,
        modifications,
        modifiedContent,
        previewUrl,
        backupId: `backup_${Date.now()}_${component.componentName}`,
        canUndo: true
      };
      
      allModifications.push(result);
    }

    console.log('✅ Modification plan generated');

    if (previewOnly) {
      // Return preview without applying changes
      return NextResponse.json({
        success: true,
        preview: true,
        modifications: allModifications,
        message: 'Preview generated - click Apply to make changes live'
      });
    } else {
      // Apply changes to actual files
      console.log('💾 Applying changes to live components...');
      
      const appliedChanges = [];
      
      for (const modification of allModifications) {
        // Create backup
        const backups = await componentAnalyzer.getBackups(modification.originalComponent.filePath);
        
        // Save modified component
        await componentAnalyzer.saveComponent(
          modification.originalComponent.filePath,
          modification.modifiedContent
        );
        
        appliedChanges.push({
          component: modification.originalComponent.componentName,
          filePath: modification.originalComponent.filePath,
          backupId: modification.backupId,
          changesApplied: modification.modifications.length
        });
      }
      
      return NextResponse.json({
        success: true,
        applied: true,
        changes: appliedChanges,
        message: `Successfully applied ${appliedChanges.length} component modifications`,
        rollbackAvailable: true
      });
    }

  } catch (error: any) {
    console.error('❌ Real modification error:', error);
    
    return NextResponse.json({
      error: 'Real modification failed',
      message: error?.message || 'Unknown error'
    }, { status: 500 });
  }
}

async function generateIntelligentModifications(
  component: ComponentInfo,
  prompt: string,
  operation: string
): Promise<ModificationPlan[]> {
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  const systemPrompt = `You are an expert React developer analyzing a component for intelligent modifications.

Component Info:
- Name: ${component.componentName}
- File: ${component.filePath}
- Current headings: ${component.structure.headings.join(', ')}
- Current text: ${component.structure.text.slice(0, 3).join(', ')}...
- Styling classes: ${component.styling.classes.slice(0, 10).join(', ')}

Your task: Generate a precise modification plan that will transform this component according to the user's prompt.

Return ONLY a JSON array of modifications in this format:
[
  {
    "type": "content|styling|structure",
    "target": "specific element to change",
    "originalValue": "current value",
    "newValue": "new value",
    "reasoning": "why this change supports the prompt"
  }
]

Focus on:
1. Content changes (headings, text, CTAs)
2. Styling improvements (classes, layout)
3. Structural enhancements (new sections, reorganization)

Make changes that are professional, conversion-focused, and suitable for enterprise clients.`;

  const userPrompt = `Prompt: "${prompt}"
Operation: ${operation}

Analyze the component and generate specific modifications that will achieve the prompt's goal.

Component content snippet:
${component.content.slice(0, 1000)}...`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: 0.3,
      max_tokens: 1000,
    });

    const result = completion.choices[0]?.message?.content || '[]';
    
    try {
      return JSON.parse(result);
    } catch {
      // Fallback to basic modifications if AI response isn't valid JSON
      return generateFallbackModifications(component, prompt);
    }
  } catch (error) {
    console.error('AI modification generation failed:', error);
    return generateFallbackModifications(component, prompt);
  }
}

function generateFallbackModifications(component: ComponentInfo, prompt: string): ModificationPlan[] {
  const modifications: ModificationPlan[] = [];
  
  // Basic enterprise-focused modifications
  if (prompt.toLowerCase().includes('enterprise')) {
    if (component.structure.headings.length > 0) {
      modifications.push({
        type: 'content',
        target: 'heading',
        originalValue: component.structure.headings[0],
        newValue: 'Enterprise-Grade Solutions for Fortune 500 Companies',
        reasoning: 'Updated to emphasize enterprise focus'
      });
    }
  }
  
  if (prompt.toLowerCase().includes('roi')) {
    modifications.push({
      type: 'content',
      target: 'cta',
      originalValue: 'Get Started',
      newValue: 'Calculate Your ROI',
      reasoning: 'Updated CTA to emphasize measurable outcomes'
    });
  }
  
  return modifications;
}

async function generatePreviewUrl(filePath: string, modifiedContent: string): Promise<string> {
  // In a real implementation, this would:
  // 1. Create a temporary preview version of the component
  // 2. Generate a unique preview URL
  // 3. Set up a preview route that renders the modified component
  
  const previewId = `preview_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Store preview content temporarily (in real implementation, use database or cache)
  // For now, return a preview identifier
  return `/api/preview/${previewId}`;
}

function getComponentPath(pageName: string): string {
  const pageMap: { [key: string]: string } = {
    'Homepage': 'app/page.tsx',
    'About Us': 'app/about/page.tsx',
    'Services': 'app/services/page.tsx',
    'UX Research': 'app/services/ux-research/page.tsx',
    'Product Discovery': 'app/services/product-discovery/page.tsx',
    'Case Studies': 'app/case-studies/page.tsx',
    'Contact': 'app/contact/page.tsx',
    'Admin Dashboard': 'components/AdminDashboard.tsx'
  };
  
  return pageMap[pageName] || 'app/page.tsx';
}

// Handle rollback requests
export async function DELETE(request: NextRequest) {
  try {
    const { filePath, backupId } = await request.json();
    
    if (!filePath || !backupId) {
      return NextResponse.json({ error: 'File path and backup ID required' }, { status: 400 });
    }
    
    const backups = await componentAnalyzer.getBackups(filePath);
    const backupFile = backups.find(backup => backup.includes(backupId));
    
    if (!backupFile) {
      return NextResponse.json({ error: 'Backup not found' }, { status: 404 });
    }
    
    await componentAnalyzer.restoreBackup(filePath, backupFile);
    
    return NextResponse.json({
      success: true,
      message: `Successfully rolled back ${filePath}`,
      restoredFrom: backupFile
    });
    
  } catch (error: any) {
    return NextResponse.json({
      error: 'Rollback failed',
      message: error?.message || 'Unknown error'
    }, { status: 500 });
  }
}

// Get modification history
export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const filePath = url.searchParams.get('filePath');
    
    if (!filePath) {
      // Return all analyzed components
      const components = await componentAnalyzer.analyzeAllPages();
      return NextResponse.json({
        components: components.map(comp => ({
          name: comp.componentName,
          path: comp.filePath,
          headings: comp.structure.headings,
          lastModified: 'Unknown' // Would get from file system
        }))
      });
    }
    
    // Return specific component history
    const backups = await componentAnalyzer.getBackups(filePath);
    const component = await componentAnalyzer.analyzeComponent(filePath);
    
    return NextResponse.json({
      component: {
        name: component.componentName,
        path: component.filePath,
        current: component.structure
      },
      backups: backups.map(backup => ({
        id: backup,
        timestamp: backup.split('.').pop(),
        canRestore: true
      }))
    });
    
  } catch (error: any) {
    return NextResponse.json({
      error: 'Failed to get component info',
      message: error?.message || 'Unknown error'
    }, { status: 500 });
  }
}
